package simu;

import java.util.Vector;
import simu.Server;

public class Server {
	static final int sleep = 0;  // 服务器状态常量休假
	static final int DELAY = 1;   // 服务器状态常量延迟休假
	static final int BUSY = 2;   // 服务器状态常量忙
	static final int IDLE = 3;   // 服务器状态常量闲
	int num; // 服务器编号
	int state; // 服务器状态
	Vector sleep_starttime; // 定义可变向量 睡眠开始时间 
	Vector sleep_endtime; // 定义可变向量 睡眠结束时间
	Vector busy_starttime; // 定义可变向量 忙期开始时间
	Vector busy_endtime; // 定义可变向量 忙期结束时间
	Vector delay_starttime; // 定义可变向量 延迟休假开始时间
	Vector delay_endtime; // 定义可变向量 延迟休假结束时间
	Vector idle_starttime; // 定义可变向量 空闲开始时间
	Vector idle_endtime; // 定义可变向量 空闲开始时间
	double remain_busytime; // 当前作业剩余执行时间
	double sleeptime; // 睡眠时间
	double delaytime; // 延迟休假时间

	//返回空闲的server数组
		 static Server[] idleSever(Server s[])
		 {
			 Server idleserver[]=null;
			 int idlecount=0;
			 for(int i=0;i<s.length;i++)
			 {
				if( s[i].state==Server.IDLE)
				{			
					idlecount++;				
				}			 
				 
			 }
			 if(idlecount!=0)
			 idleserver=new Server[idlecount];
			 int n=0;
			 for(int i=0;i<s.length;i++)
			 {
				if( s[i].state==Server.IDLE)
				{			
					idleserver[n]=s[i];
					n++;
				}			 
				 
			 }
			 
			 return idleserver;	 
		 }
		 //找到第一个空闲的server
		 static Server findFirstIdleServer(Server v[])
		 {
			 Server idleServers[]=Server.idleSever(v);
			 if(idleServers!=null)
			 {
				 return idleServers[0];
			 }
			 else
				 return null;
		 }
		// 判断是否有空的server,返回空的server数量
		static int idleserver(Server s[]) {
			int n = 0;
			for (int i = 0; i < s.length; i++) {
				if (s[i].state == Server.IDLE)
					n = n + 1;
			}
			
			return n;

		}

		// 判断是否有忙的server，返回数量
		static int busyservernum(Server s[]) {
			int count = 0;
			for (int i = 0; i < s.length; i++) {
				if (s[i].state == Server.BUSY)
					count = count + 1;
			}
			return count;
		}
		//返回忙碌的服务器数组	 
		 static  Server[]   getBusyServers(Server s[])
		 {   Server Bserver[]=null;
			 int num=0;
			 
			 for(int i=0;i<s.length;i++)
			 {			 
				 if(s[i].state==Server.BUSY)
				 {			 
					 num++;				 
				 }
				 
			 }
			 if (num!=0)
			 {
			    Bserver=new Server[num]; 
			    num=0;
			   for(int i=0;i<s.length;i++)
			   {			 
				 if(s[i].state==Server.BUSY)
				 {	 Bserver[num]=s[i];	 
					 num++;				 
				 }		 
			    }
			 }
			 return Bserver;		 
		 }	 
		 //得到当前最小的作业,剩余执行时间
		 static double getMinBusy(Server v[])
		 {   
			 int count = busyservernum(v);
			 Server Bserver[] = null;
			 double minBusy = 0.0; 
			 if (count>0)
			 {
				 Bserver=getBusyServers(v);
				 minBusy=Bserver[0].remain_busytime;
				 for(int i=1;i<count;i++)
				 {
					 if(Bserver[i].remain_busytime< minBusy)
						 minBusy=Bserver[i].remain_busytime;	
				 }
			 }
			 return minBusy;		 
		 }
	}

		

