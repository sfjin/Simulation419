package simu;
import simu.Exponentdist;

public class Exponentdist{
//生成指数分布
	public static double sample(double lamda){
		double x, z;
    	z = Math.random();
		x = -(1 / lamda) * Math.log(z);
		return x;
	}
}
