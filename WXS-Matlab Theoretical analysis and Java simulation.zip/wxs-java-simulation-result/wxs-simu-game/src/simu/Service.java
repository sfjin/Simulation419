package simu;

import java.util.*;


import simu.Service;
import simu.Job;
import simu.Exponentdist;
import simu.Server;

public class Service {
	static double currenttime; // 当前时间
	static Job job[]; // 作业数组
	static Server server[]; // 服务器数量

	static double lambda; // 到达率
	static double mu = 0.2; // 服务率
	static int n = 20; // 服务器个数
    static double theta = 0.4; // 休假参数
	static double beta = 1.2; // 延迟休假参数
	static final double ca=20;//唤醒耗能
	static final double cs=2;//睡眠耗能
	static final double cl=4;//监听耗能
	static final double ct=12;//切换耗能

	// 初始化
	static void init() {
		// 初始化作业长度和编号
		job = new Job[5000];
		for (int i = 0; i < job.length; i++) {
			job[i] = new Job();
			job[i].size = Exponentdist.sample(mu);
			job[i].num = i + 1;
		}
		// 初始化作业到达时间；
		job[0].arrive_time = Exponentdist.sample(lambda);
		for (int j = 0; j < job.length - 1; j++) {
			double t = Exponentdist.sample(lambda);
			job[j + 1].arrive_time = job[j].arrive_time + t;
		}
	}// 初始化结束
	
		// 判断系统处于延迟休假
	static boolean isDelay(Server server[]) {
		boolean a = true;
		for (int i = 0; i < server.length; i++) {
			a = a & (server[i].state == Server.DELAY);
		}
		return a;
	}

	// 判断系统处于休假
	static boolean isSleep(Server server[]) {
		boolean b = true;
		for (int i = 0; i < server.length; i++) {
			b = b & (server[i].state == Server.sleep);
		}
		return b;
	}

	// 判断系统全部处于闲状态
	static boolean isIdle(Server server[]) {
		boolean b = true;
		for (int i = 0; i < server.length; i++) {
			b = b & (server[i].state == Server.IDLE);
		}
		return b;
	}

	public static void main(String[] args) {
		System.out.println("系统开始运行......");
		int j = 0;
		Double[] RESPONSEtime = new Double[20];// 平均延迟时间
		Double[] P0 = new Double[20];    //存储不同的lambda，对应的不同的最终P0	
		//Double[] P1 = new Double[20];    //存储不同的lambda，对应的不同的最终P1
		//Double[] P2 = new Double[20];    //存储不同的lambda，对应的不同的最终P2
		Double[] timeend = new Double[20]; //存储不同的lambda，对应的不同的最终Service.currenttime
		Double[] save = new Double[20];   //存储不同的lambda，对应的不同的节能水平	
		for(lambda = 0.1; lambda < 3.9;lambda = lambda + 0.3){
			P0[j] = 0.0;
			//P1[j] = 0.0;
			//P2[j] = 0.0;
			init(); // 初始化
			//System.out.print(job[0].arrive_time);
			Service.currenttime = 0;
			// 初始化服务器状态
			server = new Server[n];
			double delaytime1 = Exponentdist.sample(beta);
			for (int i = 0; i < server.length; i++) {
				server[i] = new Server();
				server[i].num = i + 1;
				server[i].state = Server.DELAY;
				server[i].sleep_starttime = new Vector<Double>();
				server[i].sleep_endtime = new Vector<Double>();
				server[i].busy_starttime = new Vector<Double>();
				server[i].busy_endtime = new Vector<Double>();
				server[i].delay_starttime = new Vector<Double>();
				server[i].delay_endtime = new Vector<Double>();
				server[i].idle_starttime = new Vector<Double>();
				server[i].idle_endtime = new Vector<Double>();
				server[i].delay_starttime.addElement(new Double(0.0));
				server[i].delaytime = delaytime1;
			}
			while (Service.currenttime < job[4990].arrive_time) {
//				System.out.println("1当前时间 :" + Service.currenttime);
//				System.out.println("2最后作业到达时间:" + job[4990].arrive_time);
				if (Job.getWaitJobs(job) == null)// 若没有等待作业
				{
					if (Server.busyservernum(server) == 0)// server全部空闲
					{
						// ----1.1------
						//System.out.println("系统是否全部延迟休假："+Service.isDelay(server));
						if (Service.isDelay(server) == true) {
//							System.out.println("1.1开始运行");
//							System.out.println("无等待作业，server全部空闲,系统处于延迟休假状态");
							Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
							double minarrive = firstunarrivejob.arrive_time - Service.currenttime;
//							System.out.println("最小到达时间" + minarrive);
//							System.out.println("服务器延迟休假时间：" +server[0].delaytime);
							if (minarrive < server[0].delaytime) {
//								System.out.println("1.1.1开始运行,延迟休假 ，先到达");
								double before = Service.currenttime;
								Service.currenttime = Service.currenttime + minarrive;// 更新系统时间
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.1.1出现减少");
									break; // 跳出循环
								}
								server[0].delay_endtime.addElement(new Double(Service.currenttime));
								server[0].state = Server.BUSY;// 第一个服务器由delay变为busy
								server[0].busy_starttime.addElement(new Double(Service.currenttime));
								firstunarrivejob.server = server[0]; // 为该Job配置空闲服务器
								firstunarrivejob.state = Job.RUN;
								firstunarrivejob.start_time = Service.currenttime;
								server[0].remain_busytime = firstunarrivejob.size;
								for (int i = 1; i < n; i++) {
									server[i].delay_endtime.addElement(new Double(Service.currenttime));
									server[i].state = Server.IDLE;
									server[i].idle_starttime.addElement(new Double(Service.currenttime));
								}
							} else {
//								System.out.println("1.1.2开始运行");
//								System.out.println("无等待作业，server全部空闲,延迟休假状态结束，系统处于休眠状态");
								double before = Service.currenttime;
								Service.currenttime = Service.currenttime + server[0].delaytime;// 更新系统时间
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.1.2出现减少");
									break; // 跳出循环
								}
								double sleeptime1 = Exponentdist.sample(theta);
								for (int i = 0; i < n; i++) {
									server[i].delay_endtime.addElement(new Double(Service.currenttime));
									server[i].state = Server.sleep;
									server[i].sleep_starttime.addElement(new Double(Service.currenttime));
									server[i].sleeptime = sleeptime1;
								}

							}
						} else if (Service.isSleep(server) == true) {
							// ----------------1.2-----------
							//System.out.println("1.2开始运行，系统处于休眠状态");
							Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
							double minarrive = firstunarrivejob.arrive_time - Service.currenttime;
//							System.out.println("最小到达时间："+minarrive);
//							System.out.println("睡眠时间："+server[0].sleeptime);
							if (minarrive < server[0].sleeptime) {
								//System.out.println("1.2.1开始运行，系统处于休眠状态，先到达作业");
								double before = Service.currenttime;
								Service.currenttime = Service.currenttime + minarrive;// 更新系统时间
								P0[j]=P0[j]+minarrive;   //处于P0状态的时间增加
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.2.1出现减少");
									break; // 跳出循环
								}
								firstunarrivejob.state = Job.WAIT;
								for(int i=0;i<server.length;i++){
									server[i].state = Server.sleep;
									server[i].sleeptime = server[i].sleeptime-minarrive;
								}
							} else {
								//System.out.println("1.2.2开始运行，系统处于休眠状态，先休眠结束");
								double before = Service.currenttime;
								//System.out.println("1.2.2系统当前时间："+Service.currenttime);
								Service.currenttime = Service.currenttime + server[0].sleeptime;// 更新系统时间
								P0[j]=P0[j]+server[0].sleeptime;   //处于P0状态的时间增加
//								P1[j]=P1[j]+minarrive;   //处于P1状态的时间增加
								//System.out.println("1.2.2系统更新后时间："+Service.currenttime);
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.2.2出现减少");
									break; // 跳出循环
								}
								double sleeptime2 = Exponentdist.sample(theta);
								for (int i = 0; i < server.length; i++) {
									server[i].sleep_endtime.addElement(new Double(Service.currenttime));
									server[i].state = Server.sleep;
									server[i].sleep_starttime.addElement(new Double(Service.currenttime));
									server[i].sleeptime = sleeptime2;
								}
							}
						}

					} else if (Server.busyservernum(server) != 0)// m个server中有繁忙的
					{
						if (Server.busyservernum(server) == server.length)// m个server全部占用
						{// --------1.3-------------
							//System.out.println("1.3开始运行,无等待作业，server全部占用");
							Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
							double minarriv = firstunarrivejob.arrive_time - Service.currenttime;
							//System.out.println("最小到达时间: " + minarriv);
							Job busyJob[] = Job.getRunJobs(job);// 得到所有运行状态的job
							double minbusy = Server.getMinBusy(server);// 最小剩余时间
							//System.out.println("最小剩余繁忙时间: " + minbusy);
							if (minarriv < minbusy)// 下一个job排队
							{
								//System.out.println("1.3.1开始，无等待作业，server全部占用，先到达job");
								double before = Service.currenttime;
								Service.currenttime = Service.currenttime + minarriv;// 更新系统时间
//								P1[j]=P1[j]+minarriv;   //处于P1状态的时间增加
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.3.1出现减少");
									break; // 跳出循环
								}
								firstunarrivejob.state = Job.WAIT;// 该job排队等待
								for (int i = 0; i < busyJob.length; i++)// 更新正在运行的Job的剩余执行时间
								{
									busyJob[i].server.remain_busytime = busyJob[i].server.remain_busytime - minarriv;
								}
							}
							// ---------1.3.2------------
							else// (minarriv > minbusy)即忙的服务器中先空出来一个
							{
								//System.out.println("1.3.2开始，无等待作业，server全部占用，先空出server");
								double before = Service.currenttime;
								//System.out.println("1.3.2系统当前时间："+Service.currenttime);
								Service.currenttime = Service.currenttime + minbusy;// 更新系统时间
//								P1[j]=P1[j]+minbusy;   //处于P1状态的时间增加
								//System.out.println("1.3.2系统更新后时间："+Service.currenttime);
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.3.2出现减少");
									break; // 跳出循环
								}
								for (int i = 0; i < busyJob.length; i++) {
									// 更新忙的服务器的剩余执行时间
									busyJob[i].server.remain_busytime = busyJob[i].server.remain_busytime - minbusy;
									//System.out.println(busyJob.length);
									//System.out.println(busyJob[i].server.remain_busytime);
								}
								for (int i = 0; i < busyJob.length; i++) { // 找到当前作业剩余运行时间为0的服务器，更新
									if (busyJob[i].server.remain_busytime == 0) {
										busyJob[i].server.busy_endtime.addElement(new Double(Service.currenttime));
										busyJob[i].server.state = Server.IDLE;
										busyJob[i].server.idle_starttime.addElement(new Double(Service.currenttime));
										busyJob[i].state = Job.FINISH;
										busyJob[i].finish_time = Service.currenttime;
										
									}
								}
							}
						} else if (Server.busyservernum(server) < server.length && Server.busyservernum(server) > 0)// 无排队，服务器不是全部占用
						{
							//System.out.println("1.4开始运行,无等待作业，server不全部占用");
							Job busyJob[] = Job.getRunJobs(job);// 得到所有运行状态的job
							double minbusy = Server.getMinBusy(server);// 最小剩余时间
							//System.out.println("最小剩余繁忙时间: " + minbusy);
							Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
							double minarriv = firstunarrivejob.arrive_time- Service.currenttime;
							//System.out.println("最小到达时间: " + minarriv);
							// -----------1.4.1--------------
							if (minarriv < minbusy)// job进入
							{
								//System.out.println("1.4.1:无等待作业，server不全部占用，先到达job");
								double before = Service.currenttime;
								//System.out.println("1.4.1系统当前时间："+Service.currenttime);
								Service.currenttime = Service.currenttime + minarriv;// 更新系统时间
//								P1[j]=P1[j]+minarriv;   //处于P1状态的时间增加
								//System.out.println("1.4.1系统更新后时间："+Service.currenttime);
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.4.1出现减少");
									break; // 跳出循环
								}
								for (int i = 0; i < busyJob.length; i++) {
									// 更新忙的服务器的剩余执行时间
									busyJob[i].server.remain_busytime = busyJob[i].server.remain_busytime - minarriv;
								}
								// 为刚到的Job分配空闲的服务器
								Server idlevm[] = Server.idleSever(server);
								//System.out.println("第一个空闲服务器:"+idlevm[0]);
								firstunarrivejob.server = idlevm[0];
								idlevm[0].idle_endtime.addElement(new Double(Service.currenttime));
								idlevm[0].state = Server.BUSY;
								idlevm[0].busy_starttime.addElement(new Double(Service.currenttime));
								idlevm[0].remain_busytime = firstunarrivejob.size;
								firstunarrivejob.state = Job.RUN;
								firstunarrivejob.start_time = Service.currenttime;
							}
							// ---------1.4.2-----------
							else// (minarr > minbusy)走一个job
							{
								//System.out.println("1.4.2开始运行，无等待作业，server不全部占用，先空出server");
								double before = Service.currenttime;
								//System.out.println("1.4.2系统当前时间："+Service.currenttime);
								Service.currenttime = Service.currenttime + minbusy;// 更新系统时间
//								P1[j]=P1[j]+minbusy;   //处于P1状态的时间增加
								//System.out.println("1.4.2系统更新后时间："+Service.currenttime);
								Job busyJob1[] = Job.getRunJobs(job);// 得到所有运行状态的job
								if (Service.currenttime < before) {
									System.out.println("FreeService.currenttime在1.4.2出现减少");
									break; // 跳出循环
								}
								//System.out.println("busyjob长度1.4.2 "+ busyJob1.length);
								for (int i = 0; i < busyJob1.length; i++) {
									//System.out.println("busyjob1.4.2更新前 ："+ busyJob1[i].server.remain_busytime);
									// 更新忙的服务器的剩余执行时间
									busyJob1[i].server.remain_busytime = busyJob1[i].server.remain_busytime - minbusy;
								}
								for (int i = 0; i < busyJob1.length; i++) { // 找到当前作业剩余运行时间为0的服务器，更新
									//System.out.println("busyjob1.4.2更新后： "+ busyJob1[i].server.remain_busytime);
									if (busyJob1[i].server.remain_busytime == 0.0) {
										//System.out.println("剩余时间为0的服务器编号："+i);
										busyJob1[i].server.busy_endtime.addElement(new Double(Service.currenttime));
										busyJob1[i].server.state = Server.IDLE;
										busyJob1[i].server.idle_starttime.addElement(new Double(Service.currenttime));
										busyJob1[i].state = Job.FINISH;
										busyJob1[i].finish_time = Service.currenttime;
										//System.out.println("当前忙作业长度："+busyJob1.length);
									}
								}
								if (Service.isIdle(server) == true) {
									double delaytime2 = Exponentdist.sample(beta);
									for (int i = 0; i < n; i++) {
										server[i].idle_endtime.addElement(new Double(Service.currenttime));
										server[i].state = Server.DELAY;
										server[i].delay_starttime.addElement(new Double(Service.currenttime));
										server[i].delaytime = delaytime2;
									}
								}
							}
						}
					}
				}
				 else if (Job.getWaitJobs(job) != null)// 有等待作业
				{
					// ---------1.5------------
					if (Service.isSleep(server) == true) {
						//System.out.println("1.5开始运行，有等待作业,系统处于休眠状态");
						Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
						double minarrive = firstunarrivejob.arrive_time - Service.currenttime;
						//System.out.println("最小到达时间: " + minarrive);
						if (minarrive < server[0].sleeptime) {
							//System.out.println("1.5.1开始运行，有等待作业,系统处于休眠状态，先到达job");
							double before = Service.currenttime;
							//System.out.println("系统当前时间: " + Service.currenttime);
							Service.currenttime = Service.currenttime+ minarrive;// 更新系统时间
							P0[j]=P0[j]+minarrive;   //处于P0状态的时间增加
							//System.out.println("系统更新后时间: " + Service.currenttime);
							if (Service.currenttime < before) {
								System.out.println("FreeService.currenttime在1.5.1出现减少");
								break; // 跳出循环
							}
							firstunarrivejob.state = Job.WAIT;
							for(int i=0;i<server.length;i++){
//								server[i].state = Server.sleep;
								server[i].sleeptime = server[i].sleeptime-minarrive;
							}
						} else {
							//System.out.println("1.5.2开始运行，有等待作业,先结束睡眠");
							double before = Service.currenttime;
							Service.currenttime = Service.currenttime + server[0].sleeptime;// 更新系统时间
							P0[j]=P0[j]+server[0].sleeptime;   //处于P0状态的时间增加
//							P1[j]=P1[j]+server[0].sleeptime;   //处于P1状态的时间增加
							Job getWaitJobs[] = Job.getWaitJobs(job);// 找到排队jobs
//							System.out.println("系统当前时间: " + Service.currenttime);
							if (Service.currenttime < before) {
								System.out.println("FreeService.currenttime在1.5.2出现减少");
								break; // 跳出循环
							}
							//System.out.println("1.5.2等待作业长度："+getWaitJobs.length);
							if (getWaitJobs.length > n) {
							//	System.out.println("1.5.2.1开始运行，有等待作业,先结束睡眠，等待数>n");
								for (int i = 0; i < server.length; i++) {
									server[i].sleep_endtime.addElement(new Double(Service.currenttime));
									server[i].state = Server.BUSY;
									server[i].busy_starttime.addElement(new Double(Service.currenttime));
									getWaitJobs[i].state = Job.RUN;
									getWaitJobs[i].server = server[i];
									getWaitJobs[i].start_time = Service.currenttime;
									server[i].remain_busytime = getWaitJobs[i].size;// 剩余繁忙时间为服务时间
								}
								for (int i = n; i < getWaitJobs.length; i++) {
									getWaitJobs[i].state = Job.WAIT;
								}
								
							} else if (getWaitJobs.length < n && getWaitJobs.length > 0) {
								//System.out.println("1.5.2.2开始运行，有等待作业,先结束睡眠，等待数<n");
								for (int i = 0; i < server.length; i++) {
									server[i].sleep_endtime.addElement(new Double(Service.currenttime));
									for (int k = 0; k < getWaitJobs.length; k++) {
										server[k].state = Server.BUSY;
										server[k].busy_starttime.addElement(new Double(Service.currenttime));
										getWaitJobs[k].state = Job.RUN;
										getWaitJobs[k].server = server[k];
										getWaitJobs[k].start_time = Service.currenttime;
										server[k].remain_busytime = getWaitJobs[k].size;// 剩余繁忙时间为服务时间
									}
									for (int k = getWaitJobs.length; k < n; k++) {
										server[k].state = Server.IDLE;
										server[k].idle_starttime.addElement(new Double(Service.currenttime));	
									}
								}
							}
						}
					} else if(Server.busyservernum(server) == n){
						//System.out.println("1.6开始运行，有等待作业,系统处于全忙状态");
						Job firstunarrivejob = Job.getFirstUnarriveJob(job);// 找到第一个将要到达的job
						double minarriv = firstunarrivejob.arrive_time- Service.currenttime;
						//System.out.println("最小到达时间"+minarriv);
						Job busyJob[] = Job.getRunJobs(job);// 得到所有运行状态的job
						double minbusy = Server.getMinBusy(server);// 最小剩余时间
						//System.out.println("最小剩余时间"+minbusy);
						Job firstwaitjob = Job.getFirstWaitJob(job);// 找到排队中第一个job
						Job firstendjob = Job.min_busytime(job);// 取出剩余运行时间最小的那个job
						if (minarriv < minbusy)// job排队
						{
							//System.out.println("1.6.1开始运行，有等待作业，先到达job");
							double before = Service.currenttime;
							Service.currenttime = Service.currenttime + minarriv;// 更新系统时间
//							P1[j]=P1[j]+minarriv;   //处于P1状态的时间增加
							//System.out.println("系统更新后时间："+Service.currenttime);
							if (Service.currenttime < before) {
								System.out.println("FreeService.currenttime在1.6.1出现减少");
								break; // 跳出循环
							}
							firstunarrivejob.state = Job.WAIT;// 该job排队等待
							for (int i = 0; i < busyJob.length; i++) {
								busyJob[i].server.remain_busytime = busyJob[i].server.remain_busytime - minarriv;
							}
						}
						// ---------1.6.2--------------
						else// (minarriv > minbusy)走一个job
						{
							//System.out.println("1.6.2开始运行，有等待作业，先空出server");
							Job busyJob1[] = Job.getRunJobs(job);// 得到所有运行状态的job
							double before = Service.currenttime;
							Service.currenttime = Service.currenttime + minbusy;// 更新系统时间
							//System.out.println("系统更新后时间："+Service.currenttime);
							if (Service.currenttime < before) {
								System.out.println("FreeService.currenttime在1.6.2出现减少");
								break; // 跳出循环
							}
							for (int i = 0; i < busyJob1.length; i++) {
								 //System.out.println("busyjob1.6.2更新前忙作业长度 " + busyJob1.length);
								// System.out.println("busyjob1.6.2更新前剩余时间 " + busyJob[i].server.remain_busytime);
								// 更新忙的服务器的剩余执行时间
								busyJob1[i].server.remain_busytime = busyJob1[i].server.remain_busytime - minbusy;
								// System.out.println("busyjob1.6.2更新后剩余时间 " + busyJob[i].server.remain_busytime);
							}
							for (int i = 0; i < busyJob1.length; i++) { // 找到当前作业剩余运行时间为0的服务器，更新
								if (busyJob1[i].server.remain_busytime == 0.0) {
									busyJob1[i].server.busy_endtime.addElement(new Double(Service.currenttime));
									busyJob1[i].server.state = Server.IDLE;
									busyJob1[i].server.idle_starttime.addElement(new Double(Service.currenttime));
									busyJob1[i].state = Job.FINISH;
									busyJob1[i].finish_time = Service.currenttime;
									//System.out.println("busyjob1.6.2更新后忙作业长度 " + busyJob1.length);
								}
							}
							Server idlevm[] = Server.idleSever(server);
							//System.out.println("第一个空闲服务器:"+idlevm[0]);
							firstwaitjob.server = idlevm[0];
							firstwaitjob.server.idle_endtime.addElement(new Double(Service.currenttime));
							firstwaitjob.server.state = Server.BUSY;
							firstwaitjob.server.busy_starttime.addElement(new Double(Service.currenttime));
							firstwaitjob.server.remain_busytime = firstwaitjob.size;
							firstwaitjob.state = Job.RUN;
							firstwaitjob.start_time = Service.currenttime;
//							System.out.println("end:" + firstendjob.server.num);
//							System.out.println("wait:"+ firstwaitjob.server.num);

						}

					}
				}

			}
			

			timeend[j] = Service.currenttime;	
			P0[j]=P0[j]/timeend[j];
			
			//System.out.print(a);
			//save[j] = P0[j]*wl*n;
			save[j] = P0[j]*(ca-cs)-P0[j]*cl*theta-P0[j]*ct*theta;
			// 取平稳状态的作业，计算平均逗留时间
			double finishnum = 0;// 正在运行和完成服务的作业数量
			double allresponsetime = 0;// 等待时间总和
			for (int i = 2000; i < 4000; i++) {
				if (job[i].state == Job.RUN ||job[i].state == Job.FINISH) {
					allresponsetime = allresponsetime + (job[i].finish_time - job[i].arrive_time);
					finishnum++;
				}
			}
			double responsetime = allresponsetime / finishnum;
			RESPONSEtime[j] = responsetime;// 为等待作业长度添加一个元素
			j++;// 结果值位置增加一
		}// 到达率循环结束
	
		
		
		// 输出平均响应时间
		System.out.println("平均响应时间 :");
		for (int i = 0; i < 20; i++) {
			String double_str = String.format("%.4f",RESPONSEtime[i] );
			System.out.print(double_str + ",");
		}
		System.out.println();
//		// 输出概率
//				System.out.println("sleep :");
//				for (int i = 0; i < 8; i++) {
//					String double_str = String.format("%.4f",sleeptime[i] );
//					System.out.print(double_str + ",");
//				}
		// 输出节能水平
		System.out.println();
				System.out.println("节能水平 :");
				for (int i = 0; i < 20; i++) {
					String double_str = String.format("%.4f",save[i] );
					System.out.print(double_str + ",");
				}
				System.out.println();
//				// 输出利用率
//				System.out.println();
//						System.out.println("利用率 :");
//						for (int i = 0; i < 8; i++) {
//							String double_str = String.format("%.4f",utilization[i] );
//							System.out.print(double_str + ",");
//						}


	}// main的结束
}

