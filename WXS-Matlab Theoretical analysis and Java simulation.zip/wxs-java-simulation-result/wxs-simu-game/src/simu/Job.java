package simu;

import java.util.Random;

import simu.Server;
import simu.Service;
import simu.Job;

public class Job {
	static final int UNARRIVE = 0;// 作业的状态常�?
	static final int WAIT = 1;// 作业的状态常�?
	static final int RUN = 2;// 作业的状态常�?
	static final int FINISH = 3;// 作业的状态常�?
	int num; // 作业编号
	double size; // 作业长度
	double arrive_time; // 作业的到达时间
	double start_time; // 作业的开始执行时间
	double finish_time; // 作业的结束时间
	int state; // 作业的状态
	Server server; // 运行分配的服务器

	public Job() // 无参构造方法，初始化作业的长度，状态
	{
		state = Job.UNARRIVE;
		server = null;
	}

		// 得到未到达的作业数量
		 static int getUnarriveJobsNum(Job j[])
		 {
			 int count=0;
			 for(int i=0;i<j.length;i++)
			 {			 
				 if(j[i].arrive_time > Service.currenttime)
				 {			 
					 count++;				 
				 }			 
			 }
			 return count;
		 }
		 
		 //得到未到达的作业队列，按照到达时间（未到）从早到晚排列
		 static  Job[]  getUnarriveJobs(Job j[])
		 {  
			 Job unjob[]=null;	
			 int count=getUnarriveJobsNum(j);
			 if(count!=0)
			 {
				 unjob=new Job[count];
				 int num=0;
				 for(int i=0;i<j.length;i++)
				 {			 
					 if(j[i].arrive_time > Service.currenttime)
					 {	 
						 unjob[num]=j[i];	 
						 num++;				 
					 }				 
				 }
			 }
			 return unjob;
			 
		 }	 
	 
		//得到下一个即将到来的作业
		 static Job getFirstUnarriveJob(Job j[])
		 {
		 	Job unj[]=Job.getUnarriveJobs(j);
		 	if(unj!=null)		 	
		       return unj[0];
		 	else
		 	   return null;
		 }	
		 //得到等待的作业队列，按照时间从小到大排列
		 static  Job[]   getWaitJobs(Job j[])
		 {  
			 Job wjob[]=null;
			 int num=0;
			 
			 for(int i=0;i<j.length;i++)
			 {			 
				 if(j[i].state==Job.WAIT)
				 {			 
					 num++;				 
				 }
				 
			 }
			 if(num!=0)
			 {
				 wjob=new Job[num];
				 num=0;
				 for(int i=0;i<j.length;i++)
				 {			 
					 if(j[i].state==Job.WAIT)
					 {
						 wjob[num]=j[i];	 
						 num++;				 
					 }

				 }
			 }
			 return wjob;
			 
		 }	 
		 //得到运行的作业数组	 
		 static Job[] getRunJobs(Job j[])
		 {   Job Rjob[]=null;
			 int num=0;
			 
			 for(int i=0;i<j.length;i++)
			 {			 
				 if(j[i].state==Job.RUN)
				 {			 
					 num++;				 
				 }
				 
			 }
			 if (num!=0)
			 {
			    Rjob=new Job[num]; 
			    num=0;
			   for(int i=0;i<j.length;i++)
			   {			 
				 if(j[i].state==Job.RUN)
				 {	 Rjob[num]=j[i];	 
					 num++;				 
				 }		 
			    }
			 }
			 return Rjob;
			 
		 }	 
		 	 
		//找到等待队列的第一个作业
		 static Job getFirstWaitJob(Job j[])
		 {
		 	Job wj[]=Job.getWaitJobs(j);
		 	if(wj!=null)
		 	{
		 	return wj[0];
		 	}
		 	else
		 	return null;
		 }
		//返回当前时刻有几个等待的作业
		 static int waitjobnum(double currenttime,Job wjob[])
		 {    int n=0;
			  if (wjob!=null)
			  {
		 	   for(int i=0;i<wjob.length;i++)
		 	   {
		 		if( wjob[i].arrive_time<currenttime)
		 		{	  
		 			n=n+1;		
		 		}	 		
		 	   }  	
		      } 
			 return n;
	     }
		//返回运行作业数组中剩余时间最少的作业
		 static Job  min_busytime(Job j[])
		 {
		 	double min=0;
		 	int index=-1;
		 	Job Rjob[]=Job.getRunJobs(j);
		 	if(Rjob!=null)
		 	{	 	   		
		 		 min=Rjob[0].server.remain_busytime; 
		 		 index=0;
		 		 for(int i=0;i<Rjob.length;i++)
		 		 {    			
		 			if( min>Rjob[i].server.remain_busytime)
		 			{
		 				min=Rjob[i].server.remain_busytime;
		 			    index=i;
		 			 }	    
		 		  }	 			
		      }	 
		 	if(index!=-1)
		 	return Rjob[index];
		 	else
		 	return null;
		 }	 
		
	}